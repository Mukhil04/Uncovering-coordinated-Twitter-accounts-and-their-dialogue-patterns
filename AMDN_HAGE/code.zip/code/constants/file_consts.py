MONTHLY_PER_HOUR = 'month/hour'
FLAT_MONTHLY_PER_HOUR = 'flat_month_hour'
PER_DAY = 'day'