NS_URL = 'ns_url'
NS_LABEL = 'ns_label'
NS_CURATOR = 'curator'

LABEL_CONSPIRACY = 'conspiracy'
LABEL_UNRELIABLE = 'unreliable'
ALL_TWEETS = 'labeled_and_unlabeled_tweets'

EXPD_URL = 'expanded_url'
WWW_PREFIX = 'www.'
NS = 'news_source'