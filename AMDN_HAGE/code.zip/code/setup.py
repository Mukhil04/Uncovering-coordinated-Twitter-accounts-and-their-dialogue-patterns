from setuptools import setup, find_packages


setup(name='dpp',
      version='0.1.0',
      packages=find_packages('.'),
      zip_safe=False)
